package assignment2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrationSignIn {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://www.olay.co.uk/en-gb");
				driver.manage().window().maximize();
				driver.findElement(By.xpath("//a[contains(text(),'Register')]")).click();
				driver.findElement(By.xpath("//input[@data-key='emailAddress']")).sendKeys("test123@gmail.com");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//input[@data-key='newPassword']")).sendKeys("test@123");
				driver.findElement(By.xpath("//input[@id='phdesktopbody_0_grs_account[password][confirm]']")).sendKeys("test@123");
				Thread.sleep(1000);
				Select date = new Select(driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[birthdate][day]']")));
				date.selectByValue("06");
				Thread.sleep(1000);
				Select month = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_month]']")));
				month.selectByValue("05");
				Thread.sleep(1000);
				Select year = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_year]']")));
				year.selectByValue("1995");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id=\"phdesktopbody_0_submit\"]")).click();
				Thread.sleep(2000);
				
				//GERMAN REGISTRATION
				
				driver.get("https://www.olaz.de/de-de");
				driver.findElement(By.xpath("//a[contains(text(),'Registrieren')]")).click();
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_imgfemale']")).click();
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[firstname]']")).sendKeys("FirstNameTest");
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_consumer[lastname]']")).sendKeys("LastNameTest");
				
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[emails][0][address]']")).sendKeys("dharshinisivapriya@gmail.com");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[password][password]']")).sendKeys("test@123");
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_grs_account[password][confirm]']")).sendKeys("test@123");
				Thread.sleep(1000);
				Select date2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_day]']")));
				date2.selectByValue("06");
				Thread.sleep(1000);
				
				Select month2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_month]']")));
				month2.selectByValue("05");
				Thread.sleep(1000);
				
				Select year2 = new Select(driver.findElement(By.xpath("//*[@data-key='birthdate[dateselect_year]']")));
				year2.selectByValue("1995");
				Thread.sleep(1000);
				
				Select land = new Select(driver.findElement(By.xpath("//*[@data-key='addressCountry']")));
				land.selectByValue("DEU");
				Thread.sleep(1000);
				
				driver.findElement(By.xpath("//*[@data-key='addressStreet1']")).sendKeys("Addressline 1");
				driver.findElement(By.xpath("//*[@data-key='addressPostalCode']")).sendKeys("6035698");
				driver.findElement(By.xpath("//*[@data-key='addressCity']")).sendKeys("Berlin");
				
				driver.findElement(By.xpath("//*[@id='phdesktopbody_0_submit']")).click();
				Thread.sleep(2000);
				
				driver.close();
	}


}
