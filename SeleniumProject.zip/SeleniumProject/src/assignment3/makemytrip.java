package assignment3;

import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class makemytrip {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		

		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://www.makemytrip.com/");
				driver.manage().window().maximize();
				driver.findElement(By.xpath("//*[@id='fromCity']")).click();
				driver.findElement(By.xpath("//*[@placeholder='From']")).sendKeys("MAA");
				driver.findElement(By.xpath("//p[contains(text(),'Chennai, India')]")).click();
				
				driver.findElement(By.xpath("//*[@placeholder='To']")).sendKeys("BOM");
				driver.findElement(By.xpath("//p[contains(text(),'Mumbai, India')]")).click();
				
				driver.findElement(By.xpath("//div[@aria-label='Wed Apr 15 2020']")).click();
				
				driver.findElement(By.xpath("//a[contains(text(),'Search')]")).click();
				Thread.sleep(5000);
				driver.findElement(By.xpath("//*[@id=\"bookbutton-RKEY:ab9d60b2-ce5a-4688-98be-757539c86ed8:3_0\"]")).click();
				driver.findElement(By.xpath("//*[@id=\"fli_list_item_600ac52a-7ace-4f6e-813c-bcf0fa6dc0c1\"]/div[3]/div[1]/div[2]/div[2]/button")).click();
				Thread.sleep(3000);
				
				ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
			    driver.switchTo().window(tabs2.get(1));
				
	}

}
