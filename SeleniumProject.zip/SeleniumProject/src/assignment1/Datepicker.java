package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Datepicker {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://demoqa.com/datepicker/");
				driver.manage().window().maximize();
				
				driver.findElement(By.xpath("//input[@id=\"datepicker\"]")).sendKeys("05/06/1995");
	         	System.out.print("Date is selected");
	         	
	         	driver.close();  

	}

}
