package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Selectmenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://demoqa.com/selectmenu/");
				driver.manage().window().maximize();
				
				driver.findElement(By.xpath("//span[@id='speed-button']")).click();
				driver.findElement(By.xpath("(//li/div[contains(text(),'Slow')])[2]")).click();
	         	System.out.print("Speed is selected");
	         	
	         	driver.findElement(By.xpath("//span[@id='files-button']")).click();
				driver.findElement(By.xpath("//li/div[contains(text(),'Some unknown file')]")).click();
	         	System.out.print("File is selected");
	         	
	         	driver.findElement(By.xpath("//span[@id='number-button']")).click();
				driver.findElement(By.xpath("(//li/div[contains(text(),'4')])[1]")).click();
	         	System.out.print("Number is selected");
	         	
	         	driver.findElement(By.xpath("//span[@id='salutation-button']")).click();
				driver.findElement(By.xpath("//li/div[contains(text(),'Other')]")).click();
	         	System.out.print("Title is selected");
	         	
	         	//*[@id="speed-button"]
	         	
	         	driver.close();  

	}

}
