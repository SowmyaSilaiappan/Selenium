package assignment1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Controlgroup {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://demoqa.com/controlgroup/");
				driver.manage().window().maximize();
				
				driver.findElement(By.xpath("//*[@id='content']/div[2]/div/fieldset[2]/div/label[1]")).click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='vertical-spinner']")).sendKeys("2");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id=\"book\"]")).click();
				Thread.sleep(1000);
				
				driver.close();
				
				

	}

}
