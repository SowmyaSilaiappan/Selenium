package assignment1;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1 {
	
	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver","D:\\ChromeDriver\\chromedriver.exe"); 
		WebDriver driver = new ChromeDriver();
		
				driver.get("https://demoqa.com/selectable/");
				driver.manage().window().maximize();
				
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[1]")).click();
				System.out.println("Item 1");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[2]")).click();
				System.out.println("Item 2");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[3]")).click();;
				System.out.println("Item 3");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[4]")).click();;
				System.out.println("Item 4");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[5]")).click();;
				System.out.println("Item 5");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[6]")).click();;
				System.out.println("Item 6");
				Thread.sleep(1000);
				driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[2]/div[2]/ol/li[7]")).click();;
				System.out.println("Item 7");
				Thread.sleep(1000);
				
				driver.get("https://demoqa.com/html-contact-form/");
				driver.manage().window().maximize();
				
				driver.findElement(By.xpath("//input[@class='firstname']")).sendKeys("Sivapriya");
				Thread.sleep(1000);
				System.out.println("Firstname is printed");
				driver.findElement(By.xpath("//input[@id='lname']")).sendKeys("Ganapathy");
				Thread.sleep(1000);
				System.out.println("Lastname is printed");
				driver.findElement(By.xpath("//input[@name='country']")).sendKeys("India");
				Thread.sleep(1000);
				System.out.println("Country is printed");				
				driver.findElement(By.xpath("//textarea[@name='subject']")).sendKeys("This is for testing purpose");
				Thread.sleep(1000);
				System.out.println("Subject is printed");				
				driver.findElement(By.xpath("//input[@type='submit']")).click();
				
				driver.get("https://demoqa.com/html-contact-form/");
				
				driver.findElement(By.xpath("(//a[contains(text(),'Google Link')])[1]")).isDisplayed();
				System.out.println("First Google link is displayed");
				driver.findElement(By.xpath("//a[contains(text(),'is here')]")).isDisplayed();
				System.out.println("Second Google link is displayed");
				
				driver.findElement(By.xpath("(//a[contains(text(),'Google Link')])[1]")).click();
				driver.get("https://demoqa.com/html-contact-form/");
				driver.findElement(By.xpath("//a[contains(text(),'is here')]")).click();
				
				driver.close();  
	
	}

}
